<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Patient extends Model
{
    protected $dates = [
        'DOB',
    ];

    public function getFullNameAttribute()
    {
        return "{$this->first_name} {$this->last_name}";
    }
    public function test(){
        return $this->hasMany('App\Test','patient_id');
    }
    public function getSex(){
        if($this->gender==1)
             return "Male";
        else 
            return "Female";
       
    }
   
}
