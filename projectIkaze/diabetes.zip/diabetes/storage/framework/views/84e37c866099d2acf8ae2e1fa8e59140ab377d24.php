<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>rvip ltd</title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" id="stylesheetLight">
   
    <style>
        body{
        background:white;
        }
        </style>
</head>
<body >
        
<div class="d-flex align-items-center bg-auth " >
   
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-12 col-md-5 col-xl-4 my-5">
              
              <!-- Heading -->
              <h1 class="display-4 text-center mb-5">
                    Password reset
              </h1>
              <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="email" ><?php echo e(__('E-Mail Address')); ?></label>

                           
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>

                        <div class="form-group">
                                <button type="submit" class="btn  btn-primary mb-3">
                                    <?php echo e(__('Send Password Reset Link')); ?>

                                </button>
                        </div>
                           
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\Users\user\Documents\projectIkaze\diabetes\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>