<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    

<div class="container-fluid">
        <div class="row justify-content-center">
          <div class="col-12 col-lg-10">
              <?php if(!$errors->isEmpty()): ?>
                <div class="mt-3">
                <?php echo $__env->make('includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              
              <?php endif; ?>
               
            <!-- Header -->
            <div class="header mt-md-5">
              <div class="header-body">
                <div class="row align-items-center">
                  <div class="col">
                    
                    <!-- Pretitle -->
                   

                    <!-- Title -->
                    <h1 class="header-title">
                     search  Patient
                    </h1>

                  </div>
                  <div class="col-auto">
                  <a href="<?php echo e(route('patient.create')); ?>" class="btn btn-primary">create new patient</a>
                  </div>
                </div> <!-- / .row -->
              </div>
            </div>

            <!-- Form -->
                      
<?php echo Form::open(['method'=>'POST','action'=>'PatientController@searchID']); ?>

<div class="row mt-5">
    <div class="col-4">

    <label>
     Patient ID:
    </label>
    <?php echo Form::text('id',null,['class'=>'form-control','required' => 'required']); ?>

   
  </div>
 
  

  <!-- Project cover -->
  
 
  <div class="mt-5 col-2">

        <?php echo Form::submit('search',['class'=>'btn btn-block btn-primary']); ?>

</div>
</div>

<?php echo Form::close(); ?>

<hr class="mt-5 mb-4">
           <h3 class="text-center">OR</h3>
<?php echo Form::open(['method'=>'POST','action'=>'PatientController@searchByNames']); ?>

<div class="row">
<div class="col-5" >
    <div>
    <label>
     patient first name:
    </label>
    <?php echo Form::text('first_name',null,['class'=>'form-control','required' => 'required']); ?>

   
  </div>
  <div  >
    <label>
     patient last name:
    </label>
    <?php echo Form::text('last_name',null,['class'=>'form-control','required' => 'required']); ?>

   
  </div>
</div>
<div class="col-5">
  <div class="form-group" >
    <label>
     phone:
    </label>
    <?php echo Form::text('phone',null,['class'=>'form-control','required' => 'required']); ?>

   
  </div>
 
 
  
 
  <div class="form-group">

        <?php echo Form::submit('search',['class'=>'btn btn-block btn-primary']); ?>

</div>
</div>

<?php echo Form::close(); ?>

<hr class="mt-4 mb-5">
          </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projectIkaze\diabetes\resources\views/patient/search.blade.php ENDPATH**/ ?>