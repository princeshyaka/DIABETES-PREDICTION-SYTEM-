
<?php $__env->startSection('content'); ?>
    

<div class="container-fluid">
        <div class="row justify-content-center">
          <div class="col-12 col-md-6">
              <?php if(!$errors->isEmpty()): ?>
                <div class="mt-3">
                <?php echo $__env->make('includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              
              <?php endif; ?>
               
            <!-- Header -->
            <div class="header mt-md-5 mb-5">
              <div class="header-body">
                <div class="row align-items-center">
                  <div class="col">
                    
                    <!-- Pretitle -->
                    <h6 class="header-pretitle">
                       Doctor
                    </h6>

                    <!-- Title -->
                    <h4 class="header-title">
                     update Doctor
                    </h4>

                  </div>
                </div> <!-- / .row -->
              </div>
            </div>

            <!-- Form -->
           
<?php echo Form::model($user,['method'=>'PATCH','route'=>['doctor.updateDoctor',$user->id]]); ?>

      
<div class="form-group row" >
                <label class="col-sm-4 col-form-label">
    First Name:
  </label>
  <div class="col-sm-8">
  <?php echo Form::text('first_name',null,['class'=>'form-control','required']); ?>

 </div>
</div>
<div class="form-group row" >
                <label class="col-sm-4 col-form-label">
    last Name:
  </label>
  <div class="col-sm-8">
  <?php echo Form::text('last_name',null,['class'=>'form-control','required']); ?>

  </div>
</div>

              <div class="form-group row" >
                <label class="col-sm-4 col-form-label">
                 Email:
                </label>
                <div class="col-sm-8">
                <?php echo Form::email('email',null,['class'=>'form-control','required']); ?>

                </div>
              </div>
              
              <div class="form-group row" >
                <label class="col-sm-4 col-form-label">
                  Phone:
                </label>
                <div class="col-sm-8">

                <?php echo Form::text('phone',null,['class'=>'form-control','required']); ?>

               </div>
              </div>

              <div class="form-group row" >
                <label class="col-sm-4 col-form-label">
                 role:
                </label>
                <div class="col-sm-8">
                <?php echo Form::text('role',null,['class'=>'form-control','required']); ?>

               </div>
              </div>

              <div class="form-group row" >
              <label class="col-sm-4 col-form-label">Gender </label>
                    <div class="col-sm-8">
                    <?php echo Form::select('gender', [''=>'select gender','1' => 'Male', '2' => 'Female'],$user->gender,['class'=>'form-control','required']); ?>

                </div>
              </div>
             





              <!-- Divider -->
              <hr class="mt-4 mb-5">

              <!-- Project cover -->
              
             
              <div class="form-group">
                 
                    <?php echo Form::submit('Save',['class'=>'btn btn-block btn-primary']); ?>

           </div>

           <?php echo Form::close(); ?>


          </div>
        </div> <!-- / .row -->
      </div>
      <?php $__env->stopSection(); ?>
      <?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projectIkaze\diabetes\resources\views/doctor/edit.blade.php ENDPATH**/ ?>