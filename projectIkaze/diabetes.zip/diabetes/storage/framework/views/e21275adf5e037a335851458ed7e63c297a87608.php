<?php $__env->startSection('content'); ?>
    

<div class="container-fluid">
        <div class="row justify-content-center">
          <div class="col-12 col-md-8">
              <?php if(!$errors->isEmpty()): ?>
                <div class="mt-3">
                <?php echo $__env->make('includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              
              <?php endif; ?>
               
            <!-- Header -->
            <div class="header mt-md-5">
              <div class="header-body">
                <div class="row align-items-center">
                  <div class="col">
                    
                    <!-- Pretitle -->
                    <h6 class="header-pretitle">
                      New Examination
                    </h6>

                    <!-- Title -->
                    <h3 class="header-title">
                      <?php echo e($patient->fullName); ?><br>
                      <?php if($patient->gender==1): ?>
                      Male
                      <?php else: ?> 
                      Female
                      <?php endif; ?>
                      <br><?php echo e($patient->DOB->age); ?> years old

                    </h3>

                  </div>
                </div> <!-- / .row -->
              </div>
            </div>

            <!-- Form -->
           
<?php echo Form::open(['method'=>'POST','action'=>['ExaminationController@predict',$patient->id]]); ?>


    

  
  

       
        <div class="row mt-5">
        <?php echo Form::hidden('gender',$patient->gender==2,['class'=>'form-control','required','min' => '0']); ?>

        <?php if($patient->gender==2): ?>
              <div class="col-12 col-md-6">
                  <label for="pregnancies" class=" col-form-label text-md-right">pregnancies </label>

                  <?php echo Form::number('pregnancies',null,['class'=>'form-control','required','min' => '0']); ?>

  
                                          
              </div>
          
                                         
             <?php endif; ?>
             
              <div class="col-12 col-md-6">
                  <label for="glucose" class=" col-form-label text-md-right">glucose </label>

                  <?php echo Form::number('glucose',null,['class'=>'form-control','required','min' => '0']); ?>

  
                                          
              </div>
            
                                         
              </div>
              <div class="row mt-5">
              <div class="col-12 col-md-6">
                  <label for="bloodPressure" class=" col-form-label text-md-right">bloodPressure </label>

                  <?php echo Form::number('bloodPressure',null,['class'=>'form-control','required','min' => '0']); ?>

  
                                          
              </div>
            
             
              <div class="col-12 col-md-6">
                  <label for="skinThickness" class=" col-form-label text-md-right">skinThickness </label>

                  <?php echo Form::number('skinThickness',null,['class'=>'form-control','required','min' => '0']); ?>

  
                                          
              </div>
            
                                         
              </div>
              <div class="row mt-5">
              <div class="col-12 col-md-6">
                  <label for="insulin" class=" col-form-label text-md-right">insulin </label>

                  <?php echo Form::number('insulin',null,['class'=>'form-control','required','min' => '0','step'=>'.1']); ?>

  
                                          
              </div>
            
              
              <div class="col-12 col-md-6">
                  <label for="BMI" class=" col-form-label text-md-right">BMI </label>

                  <?php echo Form::number('BMI',null,['class'=>'form-control','required','min' => '0','step'=>'.1']); ?>

  
                                          
              </div>
            
                                         
              </div>
             
              <div class="row mt-5">
              <div class="col-12 col-md-6">
                  <label for="diabetesPedigreeFunction" class=" col-form-label text-md-right">diabetes Pedigree Function </label>

                  <?php echo Form::number('diabetesPedigreeFunction',null,['class'=>'form-control','required','min' => '0','step'=>'.001']); ?>

  
                                          
              </div>
            
                                         
           
           </div>
           <div class="row mt-5">
            <div class="form-group">
      
                  <?php echo Form::submit('predict',['class'=>'text-center btn  btn-primary']); ?>

         </div>
</div>
         <?php echo Form::close(); ?>


        
      </div> <!-- / .row -->
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projectIkaze\diabetes\resources\views/examination/create.blade.php ENDPATH**/ ?>