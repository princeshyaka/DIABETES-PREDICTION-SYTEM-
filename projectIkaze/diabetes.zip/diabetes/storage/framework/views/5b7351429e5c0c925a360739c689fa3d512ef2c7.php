<?php $__env->startSection('content'); ?>
    

<div class="container-fluid">
        <div class="row justify-content-center">
          <div class="col-12 col-lg-8 col-xl-6">
              <?php if(!$errors->isEmpty()): ?>
                <div class="mt-3">
                <?php echo $__env->make('includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              
              <?php endif; ?>
               
            <!-- Header -->
            <div class="header mt-md-5">
              <div class="header-body">
                <div class="row align-items-center">
                  <div class="col">
                    
                    <!-- Pretitle -->
                    <h6 class="header-pretitle">
                      New Patient
                    </h6>

                    <!-- Title -->
                    <h1 class="header-title">
                      Create a new Patient
                    </h1>

                  </div>
                </div> <!-- / .row -->
              </div>
            </div>

            <!-- Form -->
           
<?php echo Form::open(['method'=>'POST','action'=>'PatientController@store']); ?>

               
<div class="form-group" >
  <label>
    First Name:
  </label>
  <?php echo Form::text('first_name',null,['class'=>'form-control',]); ?>

 
</div>
              <div class="form-group" >
                <label>
                  Last Name:
                </label>
                <?php echo Form::text('last_name',null,['class'=>'form-control','required']); ?>

               
              </div>
             
              <div class="form-group" >
                <label>
                 Email:
                </label>
                <?php echo Form::email('email',null,['class'=>'form-control','required']); ?>

               
              </div>
              <div class="form-group" >
                <label>
                  Address:
                </label>
                <?php echo Form::text('address',null,['class'=>'form-control','required']); ?>

               
              </div>
              <div class="form-group" >
                <label>
                  Phone:
                </label>
                <?php echo Form::text('phone',null,['class'=>'form-control','required']); ?>

               
              </div>
           


              <div class="form-row">
                <div class="col">
                    <?php echo Form::label('gender','Gender:'); ?>

                </div>
                <div class="col">
                    <?php echo Form::select('gender', [''=>'select gender','1' => 'Male', '2' => 'Female'],'',['class'=>'form-control','required']); ?>

                </div>
              </div>
              <div class="form-group">
                    <?php echo Form::label('DOB','DOB'); ?>


                    <div class="form-row">
                      <div class="col">
                      <?php echo Form::date('DOB',null,['class'=>'form-control','required']); ?>

                      </div>
                     
              </div>



              <!-- Divider -->
              <hr class="mt-4 mb-5">

              <!-- Project cover -->
              
             
              <div class="form-group">
        
                    <?php echo Form::submit('Save',['class'=>'btn btn-block btn-primary']); ?>

           </div>

           <?php echo Form::close(); ?>


          </div>
        </div> <!-- / .row -->
      </div>
      <?php $__env->stopSection(); ?>
     

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projectIkaze\diabetes\resources\views/patient/create.blade.php ENDPATH**/ ?>