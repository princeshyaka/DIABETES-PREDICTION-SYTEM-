<?php if(count($errors)>0): ?>
<div class="mt-3 col-12 col-md-8 ">
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
    
<?php endif; ?>
<div class="mt-3 col-12 col-md-8 ">
<?php if(Session::has('success')): ?>
    <div class="alert alert-success">
                       <?php echo e(session('success')); ?>

      </div>
<?php endif; ?>
<?php if(Session::has('error')): ?>
    <div class="alert alert-danger">
                       <?php echo e(session('error')); ?>

      </div>
<?php endif; ?>
</div>

<?php /**PATH C:\Users\user\Documents\projectIkaze\diabetes\resources\views/includes/errors.blade.php ENDPATH**/ ?>