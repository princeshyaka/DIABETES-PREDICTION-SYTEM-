

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12 col-lg-10 col-xl-8">
          
         
        

       
            <?php echo $__env->make('includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <h3>update email</h3>
        <!-- Form -->
        <?php echo Form::model($user,['method'=>'PATCH','route'=>['admin.updateEmail'],'class'=>'mb-4']); ?>

        

        <div class="row">
                <div class="col-12">
                  
                  <!-- Last name -->
                  <div class="form-group">
    
                    <!-- Label -->
                    <label>
                    Email address
                    </label>
    
                    <!-- Input -->
                    <?php echo Form::text('email',null,['class'=>'form-control']); ?>

    
                  </div>
    
                </div>
                </div>
          <div class="row">
            <div class="col-12">
              
              <!-- First name -->
              <div class="form-group">

                <!-- Label -->
                <label>
                CURRENT  PASSWORD
                </label>

                <!-- Input -->
                <input type="password" name="password" class="form-control" />
              

              </div>

            </div>
          </div>
            
            
          
            <?php echo Form::submit('save email',['class'=>'btn btn-primary']); ?>

              <!-- Submit -->
             
         
          <?php echo Form::close(); ?>

        
    </div> <!-- / .row -->
    </div>
</div>
<div class="row justify-content-center">
  <div class="col-12 col-lg-10 col-xl-8">
    <h3 class="mt-3">update  password</h3>
    <hr>
    <?php echo Form::open(['method'=>'PATCH','route'=>['admin.updatePassword'],'class'=>'mb-4']); ?>

        
        <div class="row">
                <div class="col-12 ">
                  
                  <!-- Last name -->
                  <div class="form-group row">
                        <label for="current" class="col-sm-5 col-form-label">CURRENT PASSWORD</label>
                        <div class="col-sm-7">
                          <input type="password" name="current" class="form-control">
                        </div>
                      </div>
                      <div class="form-group row">
                            <label for="new" class="col-sm-5 col-form-label">NEW PASSWORD</label>
                            <div class="col-sm-7">
                              <input type="password" name="new" class="form-control">
                            </div>
                          </div>
                          <div class="form-group row">
                                <label for="new" class="col-sm-5 col-form-label">CONFIRM PASSWORD</label>
                                <div class="col-sm-7">
                                  <input type="password" name="password_confirmation" class="form-control">
                                </div>
                              </div>
                      
            
          
            <?php echo Form::submit('save password',['class'=>'btn btn-primary']); ?>

              <!-- Submit -->
             
         
          <?php echo Form::close(); ?>

        
    </div> <!-- / .row -->

    </div>
        
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projectIkaze\diabetes\resources\views/administrator/profile.blade.php ENDPATH**/ ?>