<?php $__env->startSection('css'); ?>
   <style>
     body{
       
     }
   </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    

<div class="container-fluid">
        <div class="row justify-content-center">
          <div class="col-12 col-lg-8 col-xl-6">
            
              <?php if(Session::has('success')): ?>
              <div class="mt-3 col-12 col-md-8 ">
                  <div class="alert alert-success">
                                     <?php echo e(session('success')); ?>

                    </div>
              </div>
              <?php endif; ?>
               
            <!-- Header -->
            <div class="header mt-md-5">
              <div class="header-body">
                <div class="row align-items-center">
                  <div class="col">
                    
                    <!-- Pretitle -->
                    <h3 class="header-pretitle">
                     Laboratory Test result #<?php echo e($ex->id); ?>

                    </h3>

                    <!-- Title -->
                   

                  </div>
                  <div class="col-auto">
                  
                    <!-- Button -->
                  <a href="<?php echo e(route('examination.pdf',$ex->id)); ?>" class="btn btn-primary">
                     print
                    </a>
                    
                  </div>
                  
                </div> <!-- / .row -->
              </div>
            </div>
            <div class="col-12 ">
                <div class="header">
                   <div class="header-body"> 
                <div class="row align-items-center">
                    <div class="col">
                        <h5 class="mb-2">
                            Patient Id: <?php echo e($ex->patient->id); ?>

                            </h5>
                    
                      <h5 class="mb-2">
                       Patient Names: <?php echo e($ex->patient->fullName); ?>

                      </h5>
                      
                      <h5 class="mb-2">
                        Date: <?php echo e($ex->created_at->format('d M Y , H:m')); ?>

                       </h5>
                       <h5 class="mb-2">
                       Address: <?php echo e($ex->patient->address); ?>

                       </h5>
  
                      <!-- Title -->
                     
  
                    </div>
                    <div class="col-auto">
                      
                        <!-- Pretitle -->
                        <h5 class="mb-2">
                          age: <?php echo e($ex->age); ?>

                        </h5>
                      
                         <h5 class="mb-2">
                          phone: <?php echo e($ex->patient->phone); ?>

                         </h5>
    
                        <!-- Title -->
                       
    
                      </div>
                    
                  </div> <!-- / .row -->
                   </div>
                </div>
                
 
                    </div>
                    <div class="col-12">
                         <!-- Card -->
                         <div class="header">
                           <div class="header-body">
                <div class="card ">
                    <div class="card-body">
      
                      <!-- List group -->
                      <div class="list-group list-group-flush my-n3">
                        <div class="list-group-item">
                          <div class="row align-items-center">
                            <div class="col">
      
                              <!-- Title -->
                              <h5 class="mb-0">
                               glucose
                              </h5>
      
                            </div>
                            <div class="col-auto">
      
                              <!-- Time -->
                              <small class="text-muted"  >
                               <?php echo e($ex->glucose); ?> 
                              </small>
      
                            </div>
                          </div> <!-- / .row -->
                        </div>
                        <div class="list-group-item">
                          <div class="row align-items-center">
                            <div class="col">
      
                              <!-- Title -->
                              <h5 class="mb-0">
                               blood pressure
                              </h5>
      
                            </div>
                            <div class="col-auto">
      
                              <!-- Time -->
                              <small class="text-muted" >
                                <?php echo e($ex->bloodPressure); ?> 
                              </small>
      
                            </div>
                          </div> <!-- / .row -->
                        </div>
                        <div class="list-group-item">
                          <div class="row align-items-center">
                            <div class="col">
      
                              <!-- Title -->
                              <h5 class="mb-0">
                                skin thickness
                              </h5>
      
                            </div>
                            <div class="col-auto">
      
                              <!-- Text -->
                              <small class="text-muted">
                                <?php echo e($ex->skinThickness); ?>

                              </small>
      
                            </div>
                          </div> <!-- / .row -->
                        </div>
                        <div class="list-group-item">
                          <div class="row align-items-center">
                            <div class="col">
      
                              <!-- Title -->
                              <h5 class="mb-0">
                                insulin
                              </h5>
      
                            </div>
                            <div class="col-auto">
      
                              <!-- Text -->
                              <small class="text-muted">
                                 <?php echo e($ex->insulin); ?>

                               
                              </small>
      
                            </div>
                          </div> <!-- / .row -->
                        </div>
                        <div class="list-group-item">
                          <div class="row align-items-center">
                            <div class="col">
      
                              <!-- Title -->
                              <h5 class="mb-0">
                              BMI
                              </h5>
      
                            </div>
                            <div class="col-auto">
      
                              <!-- Text -->
                              <small class="text-muted">
                                 <?php echo e($ex->BMI); ?>

                               
                              </small>
      
                            </div>
                          </div> <!-- / .row -->
                        </div>
                        <div class="list-group-item">
                          <div class="row align-items-center">
                            <div class="col">
      
                              <!-- Title -->
                              <h5 class="mb-0">
                              Diabetes Predigree function
                              </h5>
      
                            </div>
                            <div class="col-auto">
      
                              <!-- Text -->
                              <small class="text-muted">
                                <?php echo e($ex->diabetesPedigreeFunction); ?>

                              </small>
      
                            </div>
                          </div> <!-- / .row -->
                        </div>
                       
                        
                        
                        <?php if($ex->patient->gender==2): ?>
                      
                        <div class="list-group-item">
                          <div class="row align-items-center">
                            <div class="col">
      
                              <!-- Title -->
                              <h5 class="mb-0">
                              Pregnancies
                              </h5>
      
                            </div>
                            <div class="col-auto">
      
                              <!-- Link -->
                              <small  class="text-muted">
                                <?php echo e($ex->pregnancies); ?>

                              </small>
      
                            </div>
                          </div> <!-- / .row -->
                        </div>
                        
                    <?php endif; ?>
                      </div>
      
                    </div>
                  </div>
                           </div>
                         </div>
                  <div class="">
                    <div class="row align-items-center">
                      <div class="col">
                          <h5 class="mb-5">
                              Collected by: <?php echo e($ex->doctor->fullName); ?>

                              </h5>
                      
                        <h5 class="mb-2">
                             Test results interpretation:
                        </h5>
                        
                        <h5 class="mb-2">
                        Diabetes disease: <?php echo e($ex->outcome?'Positive':'Negative'); ?>

                         </h5>
                       
    
                        <!-- Title -->
                       
    
                      </div>
                  </div>
      
                    </div>
                   
                </div>
              </div>
          </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projectIkaze\diabetes\resources\views/examination/show.blade.php ENDPATH**/ ?>