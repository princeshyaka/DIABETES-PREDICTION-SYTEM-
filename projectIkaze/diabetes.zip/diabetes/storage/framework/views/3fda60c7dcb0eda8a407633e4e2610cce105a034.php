<?php $__env->startSection('content'); ?>
    

<div class="container-fluid">
        <div class="row justify-content-center">
          <div class="col-12 col-lg-8 col-xl-6">
             
               
            <!-- Header -->
            <div class="header mt-md-5">
              <div class="header-body">
                <div class="row align-items-center">
                  <div class="col">
                    
                    <!-- Pretitle -->
                    <h6 class="header-pretitle">
                     Doctor
                    </h6>

                    <!-- Title -->
                    <h1 class="header-title">
                      doctor Details
                    </h1>

                  </div>
                  
                </div> <!-- / .row -->
              </div>
            </div>
            <div class="col-12 col-xl-10">

                <!-- Card -->
                <div class="card">
                  <div class="card-body">
    
                    <!-- List group -->
                    <div class="list-group list-group-flush my-n3">
                      <div class="list-group-item">
                        <div class="row align-items-center">
                          <div class="col">
    
                            <!-- Title -->
                            <h5 class="mb-0">
                             Names
                            </h5>
    
                          </div>
                          <div class="col-auto">
    
                            <!-- Time -->
                            <small class="text-muted" >
                             <?php echo e($doctor->fullName); ?> 
                            </small>
    
                          </div>
                        </div> <!-- / .row -->
                      </div>
                      <div class="list-group-item">
                        <div class="row align-items-center">
                          <div class="col">
    
                            <!-- Title -->
                            <h5 class="mb-0">
                              email
                            </h5>
    
                          </div>
                          <div class="col-auto">
    
                            <!-- Time -->
                            <small class="text-muted" >
                              <?php echo e($doctor->email); ?>

                            </small>
    
                          </div>
                        </div> <!-- / .row -->
                      </div>
                      
                      <div class="list-group-item">
                        <div class="row align-items-center">
                          <div class="col">
    
                            <!-- Title -->
                            <h5 class="mb-0">
                              Gender
                            </h5>
    
                          </div>
                          <div class="col-auto">
    
                            <!-- Text -->
                            <small class="text-muted">
                                <?php if($doctor->gender==1): ?>
                                  Male
                                  <?php else: ?> 
                                  Female
                                  <?php endif; ?>
                             
                            </small>
    
                          </div>
                        </div> <!-- / .row -->
                      </div>
                      
                      <div class="list-group-item">
                        <div class="row align-items-center">
                          <div class="col">
    
                            <!-- Title -->
                            <h5 class="mb-0">
                             Role
                            </h5>
    
                          </div>
                          <div class="col-auto">
    
                            <!-- Text -->
                            <small class="text-muted">
                              <?php echo e($doctor->role); ?>

                            </small>
    
                          </div>
                        </div> <!-- / .row -->
                      </div>
                    
                      
                      <div class="list-group-item">
                        <div class="row align-items-center">
                          <div class="col">
    
                            <!-- Title -->
                            <h5 class="mb-0">
                             Tests
                            </h5>
    
                          </div>
                          <div class="col-auto">
    
                            <!-- Link -->
                            <a href="#!" class="small">
                              <?php echo e($doctor->test->count()); ?>

                            </a>
    
                          </div>
                        </div> <!-- / .row -->
                      </div>
                    
                    </div>
    
                  </div>
                </div>
    
                <!-- Weekly Hours -->
               <?php if($doctor->test->count()>0): ?>
                <div class="card" id="paymentTable" >
                   
                    
                            <div class="table-responsive mt-5" data-toggle="lists" data-lists-values='["No", "Date","patient"]'>
                                    <table class="table  table-nowrap card-table">
                                      <thead>
                                        <tr>
                                          <th scope="col">
                                            <a href="#" class="text-muted sort" data-sort="No">#</a>
                                          </th>
                                          <th scope="col">
                                            <a href="#" class="text-muted sort" data-sort="Date">Date</a>
                                          </th>
                                          <th scope="col">
                                            <a href="#" class="text-muted sort" data-sort="Doctor">patient</a>
                                          </th>
                                       
                                        
                                         
                                          
                                          
                                         
                                         
                                          
                                        </tr>
                                      </thead>
                                      <tbody class="list">
        
                                         
                                            <?php $__currentLoopData = $doctor->test->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
        
                                          <td  class="No"><?php echo e($loop->index+1); ?></td>
                                          <td class="Date"><?php echo e($c->created_at->format('d M y')); ?></td>
                                     
                                          <td class="Doctor"><?php echo e($c->patient->fullName); ?></td>
                                           
                                          <td class="text-right">  <a href="<?php echo e(route('examination.show',$c->id)); ?>" class="btn btn-primary">
                                                              view
                                                            </a></td>
                                       
                                     
                                          
                                          
                                        
                                        
                                         
                                         
                                                
                                                                  
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                           
                                                    <td>
                                                            <nav aria-label="Page navigation example">
                                                                    
                                                      <ul class="pagination">
                                                          
                                                      </ul>
                                                            </nav>
                                                    </td>
                                                  
                                        </tr>
                                    </tfoot>
                                    </table>
                                  </div>
                    </div>
                    <?php endif; ?>
                    </div>
                </div>
              </div>
          </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

var userList = new List('paymentTable', { 
    valueNames: ["no", "date","patient"],
  page: 5,
  pagination: true
});	

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\projectIkaze\diabetes\resources\views/doctor/single.blade.php ENDPATH**/ ?>